export default function activate(api) {
  api.registerTool({
    name: 'prismflow_example',
    description: 'Return a bounded example response from a trusted executable personal plugin.',
    parameters: {
      message: { type: 'string', required: true },
    },
    output: {
      schema: { type: 'object', additionalProperties: false, properties: { message: { type: 'string', required: true } } },
      render: (_args, value) => [{ type: 'text', text: value.message }],
    },
    async execute(args) {
      return { message: String(args.message).slice(0, 1000) }
    },
  })
}
